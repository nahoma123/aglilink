
<!------ Include the above in your HEAD tag ---------->
	@extends('layouts.index')
        
