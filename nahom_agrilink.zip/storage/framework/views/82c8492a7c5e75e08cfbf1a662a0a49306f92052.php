<?php $__env->startSection('content'); ?>
	<div class="container-fluid panel-info panel" style="margine-left: 20%; margine-right:20%; width: 60%">
	  <ul class="list-group">
	  <li class="list-group-item" ><h3><b>User's List</b></h3></li>
	  <li class="list-group-item">
		  <div style="margin-left:40%">
	    <div class="input-group">
	      <input type="text" class="form-control" placeholder="Search User">
	      <span class="input-group-btn">
	        <button class="btn btn-default" type="button">Search</button>
	      </span>
	    </div><!-- /input-group -->
	  	</div><!-- /.col-lg-6 -->
		<!-- /.row -->   
		</li>
	  <li class="list-group-item">
	  		
			 
			    
			    	<table class="table table-hover">
                                    <thead>
                                                <th><b>Name</b></th>
							<th><b>Joined At</b></th>
							<th><b>email</b></th>
                                                        <th><b>Phone Number</b></th>
                                                        <th><b>Gender</b></th>
                                                        <th><b>Address</b></th>
						</thead>
                                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="pointer" >     
							<td><a href='<?php echo e("/transactions/viewuser/$user->id"); ?>' class='anchor1' data-toggle="modal" data-target="#myModal"> <?php echo e($user->name); ?> </a></td>
							<td> <?php echo e(date('d-m-Y',strtotime($user->created_at))); ?></td>
                                                        <td> <?php echo e($user->email); ?></td>
                                                        <td> <?php echo e($user->phone_number); ?> </td>
                                                        <?php if($user->gender==1): ?>   
                                                        <td>Man </td>
                                                        <?php else: ?>
                                                        <td>Woman </td>
                                                        <?php endif; ?>
                                                        <td><?php echo e($user->address); ?> </td>
                                                       
						</tr>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
					</table>
	  			
			 
			</div>
	</ul>	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>