<?php $__env->startSection('content'); ?>
	<div class="container-fluid" style="margine-left: 20%; margine-right:20%; width: 60%">
	  <ul class="list-group">
	  <li class="list-group-item" ><h3><b>Manage Bets</b></h3></li>
	  <li class="list-group-item">
		  ....
		</li>
	  <li class="list-group-item">
	  		<div class="panel panel-default">
			  <div class="panel-body">
			    <div class="well well-sm" style= "padding: 20px;margin-bottom: 0px">
			    ....
	  			</div>
			  </div>
			</div>
		  		
		</li>
	  <li class="list-group-item">
	  ............
	  	
	  </li>
		<li class="list-group-item" style="align: right"><button type="button" class="btn btn-info">Submit</button></li>
		
		</ul>	
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>