<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Popular_Category extends Model
{
    //   
    protected $table = 'popular_categories';
}